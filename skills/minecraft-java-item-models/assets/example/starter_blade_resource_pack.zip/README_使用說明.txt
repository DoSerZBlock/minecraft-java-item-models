Minecraft Java 26.2 starter-blade example

Put this ZIP into Minecraft's resourcepacks folder and enable it.
Give command:
/give @s minecraft:wooden_sword[minecraft:item_model="gray_sun:starter_blade"] 1

Editable projects are distributed beside this ZIP in the skill:
starter_blade_gui.bbmodel
starter_blade_held.bbmodel
starter_blade_palette.png

The original case used in-game screenshot feedback. This public package was
checked structurally; Blockbench and in-game display QA were not rerun.
License: MIT (see the repository LICENSE).
